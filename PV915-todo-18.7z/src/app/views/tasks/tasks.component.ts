import { Component, OnInit } from '@angular/core';
import { Task } from 'src/app/models/task';
import { DataApiServiceService } from 'src/app/services/data-api-service.service';

@Component({
  selector: 'app-tasks',
  templateUrl: './tasks.component.html',
  styleUrls: ['./tasks.component.scss']
})
export class TasksComponent implements OnInit {

  tasks: Task[] = [];
  searchFilter: string = "";

  constructor(private apiService: DataApiServiceService) { }

  ngOnInit(): void {
    this.apiService.tasks.subscribe(tasks => this.tasks = tasks);
    this.apiService.searchFilter.subscribe(filter => this.searchFilter = filter);
  }

  switchStatus(task: Task): void {
    task.isCompleted = !task.isCompleted;
  }
}
