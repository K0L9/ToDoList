import { Injectable } from '@angular/core';
import { Category } from '../models/category';
import { Task } from '../models/task';
import { SeedData } from '../data/SeedData';
import { BehaviorSubject } from 'rxjs'

@Injectable({
  providedIn: 'root'
})
export class DataApiServiceService {
  private _searchFilter: string = "";

  tasks = new BehaviorSubject<Task[]>(SeedData.tasks);
  searchFilter = new BehaviorSubject<string>(this._searchFilter);

  currentTasks: Task[] = SeedData.tasks;

  constructor() { }

  getCategories(): Category[] {
    return SeedData.categories;
  }

  getTasks(): void {
    this.tasks.next(SeedData.tasks);
  }

  getSearchFilter(): void {
    return this.searchFilter.next(this._searchFilter);
  }

  setSearchFilter(searchFilter: string): void {
    console.log("FROM SEARCH FILTER: ", searchFilter)
    const filteredTasks = searchFilter == " " ? this.currentTasks : this.currentTasks.filter(task => task.title.includes(searchFilter))
    this.currentTasks = filteredTasks;
    this.tasks.next(filteredTasks);
  }

  sortTasksByCategory(category: Category): void {
    console.log("FROM SORT TASKS: ", this.currentTasks)
    const sortedTasks = this.currentTasks.filter(task => task.category == category);
    this.currentTasks = sortedTasks;
    this.tasks.next(sortedTasks);
  }
}
